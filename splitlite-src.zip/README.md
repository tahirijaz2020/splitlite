# SplitLite (Android)

Personal expense splitting app. Data is stored inside the app on the phone.

Every push to this repo builds the APK automatically (Actions tab).
Download it from **Releases → latest → SplitLite.apk**.

The app's web code is in `www/`. Signing key: `splitlite.keystore` (keep it; all updates must be signed with it).
