/* SplitLite core logic (pure functions, no DOM). All money math is done in integer cents. */
(function (root) {
  function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }

  // Split totalCents among weights; result sums exactly to totalCents.
  function allocate(totalCents, weights) {
    var sum = weights.reduce(function (a, b) { return a + b; }, 0);
    if (!(sum > 0)) return weights.map(function () { return 0; });
    var raw = weights.map(function (w) { return totalCents * w / sum; });
    var fl = raw.map(function (r) { return Math.floor(r + 1e-9); });
    var rem = totalCents - fl.reduce(function (a, b) { return a + b; }, 0);
    var order = raw.map(function (r, i) { return [r - fl[i], i]; })
      .sort(function (a, b) { return b[0] - a[0] || a[1] - b[1]; });
    for (var k = 0; k < rem; k++) fl[order[k % order.length][1]]++;
    return fl;
  }

  function expenseBase(e) { return round2((Number(e.amount) || 0) * (Number(e.rate) || 1)); }

  // {memberId: cents} in the group's base currency
  function sharesCents(e) {
    var total = Math.round(expenseBase(e) * 100);
    var sp = e.split || { type: 'equal', included: [] };
    var vals = sp.values || {};
    var ids, weights;
    if (sp.type === 'equal') {
      ids = (sp.included || []).slice();
      weights = ids.map(function () { return 1; });
    } else {
      ids = Object.keys(vals).filter(function (id) { return Number(vals[id]) > 0; });
      weights = ids.map(function (id) { return Number(vals[id]); });
    }
    var c = allocate(total, weights);
    var out = {};
    ids.forEach(function (id, i) { out[id] = c[i]; });
    return out;
  }

  function balances(g) {
    var net = {}, paid = {}, owed = {}, total = 0;
    g.members.forEach(function (m) { net[m.id] = 0; paid[m.id] = 0; owed[m.id] = 0; });
    g.expenses.forEach(function (e) {
      var tot = Math.round(expenseBase(e) * 100);
      total += tot;
      if (e.paidBy in net) { net[e.paidBy] += tot; paid[e.paidBy] += tot; }
      var sh = sharesCents(e);
      for (var id in sh) if (id in net) { net[id] -= sh[id]; owed[id] += sh[id]; }
    });
    (g.settlements || []).forEach(function (s) {
      var c = Math.round(Number(s.amount) * 100);
      if (s.from in net) net[s.from] += c;
      if (s.to in net) net[s.to] -= c;
    });
    return { net: net, paid: paid, owed: owed, total: total };
  }

  // Fewest-payments greedy settlement
  function simplify(net) {
    var cr = [], db = [], out = [];
    for (var id in net) {
      if (net[id] > 0) cr.push([id, net[id]]);
      else if (net[id] < 0) db.push([id, -net[id]]);
    }
    while (cr.length && db.length) {
      cr.sort(function (a, b) { return b[1] - a[1]; });
      db.sort(function (a, b) { return b[1] - a[1]; });
      var amt = Math.min(cr[0][1], db[0][1]);
      out.push({ from: db[0][0], to: cr[0][0], cents: amt });
      cr[0][1] -= amt; db[0][1] -= amt;
      if (cr[0][1] === 0) cr.shift();
      if (db[0][1] === 0) db.shift();
    }
    return out;
  }

  // Who owes whom without merging across people
  function pairwise(g) {
    var m = {};
    function add(a, b, c) { if (a === b || !c) return; (m[a] = m[a] || {}); m[a][b] = (m[a][b] || 0) + c; }
    g.expenses.forEach(function (e) {
      var sh = sharesCents(e);
      for (var id in sh) add(id, e.paidBy, sh[id]);
    });
    (g.settlements || []).forEach(function (s) { add(s.from, s.to, -Math.round(Number(s.amount) * 100)); });
    var out = [], seen = {};
    Object.keys(m).forEach(function (a) {
      Object.keys(m[a]).forEach(function (b) {
        var key = [a, b].sort().join('|');
        if (seen[key]) return; seen[key] = 1;
        var d = (m[a][b] || 0) - ((m[b] && m[b][a]) || 0);
        if (d > 0) out.push({ from: a, to: b, cents: d });
        else if (d < 0) out.push({ from: b, to: a, cents: -d });
      });
    });
    return out;
  }

  root.SplitLogic = { round2: round2, allocate: allocate, expenseBase: expenseBase, sharesCents: sharesCents, balances: balances, simplify: simplify, pairwise: pairwise };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.SplitLogic;
})(typeof window !== 'undefined' ? window : globalThis);
