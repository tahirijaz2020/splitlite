package com.tahir.splitlite;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Hands a backup file opened from another app (WhatsApp, Files...) to the web code. */
@CapacitorPlugin(name = "OpenFile")
public class OpenFilePlugin extends Plugin {
    private static String pendingText = null;
    private static String pendingError = null;
    private static OpenFilePlugin instance = null;

    @Override
    public void load() {
        instance = this;
    }

    @PluginMethod
    public void getPending(PluginCall call) {
        JSObject r = new JSObject();
        if (pendingText != null) r.put("text", pendingText);
        if (pendingError != null) r.put("error", pendingError);
        pendingText = null;
        pendingError = null;
        call.resolve(r);
    }

    static void deliver(String text, String error) {
        pendingText = text;
        pendingError = error;
        if (instance != null) {
            JSObject d = new JSObject();
            d.put("ready", true);
            instance.notifyListeners("fileOpened", d, true);
        }
    }
}
