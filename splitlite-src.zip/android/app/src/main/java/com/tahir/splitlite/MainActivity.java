package com.tahir.splitlite;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
